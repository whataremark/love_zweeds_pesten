--codex-- Utility fo
 --the human player's hand and drag state
local player = {}

player.players = {
    {
        hand = {},
        faceUp = {},
        faceDown = {}
    },
    {
        hand = {},
        faceUp = {},
        faceDown = {}
    }
}

player.draggingCard = nil
player.dragOffset = { x = 0, y = 0 }

function player.init(deck)
    -- Speler 1
    player.players[1].hand = {}
    player.players[1].faceUp = {}
    player.players[1].faceDown = {}

    -- Speler 2
    player.players[2].hand = {}
    player.players[2].faceUp = {}
    player.players[2].faceDown = {}

    -- Kaarten uitdelen aan speler 1 (bijv. 5 handkaarten)
    for i = 1, 5 do
        table.insert(player.players[1].hand, deck.draw())
    end
end

--codex-- Begin dragging a card from the player's hand
function player.startDrag(x, y)
    local config = require("config")
    local padding = config.cardPadding
    local kaartHoogte = config.cardHeight
    local schaal = config.scale
    local kaartBreedte = config.cardWidth

    local w = love.graphics.getWidth()
    local x_start = (w - (#player.players[1].hand * (kaartBreedte + padding))) / 2
    local y_start = love.graphics.getHeight() - kaartHoogte - 50

    for i, kaart in ipairs(player.players[1].hand) do
        local cx = x_start + (i - 1) * (kaartBreedte + padding)
        local cy = y_start

        if x > cx and x < cx + kaartBreedte and y > cy and y < cy + kaartHoogte then
            player.draggingCard = kaart
            player.dragOffset.x = x - cx
            player.dragOffset.y = y - cy
            table.remove(player.players[1].hand, i)
            break
        end
    end
end

--codex-- Update drag offsets (UI queries mouse position directly)
function player.updateDragging()
    -- geen xy-opslag nodig; UI berekent dat live
end

--codex-- Finish dragging and return the selected card
function player.stopDrag()
    local kaart = player.draggingCard
    player.draggingCard = nil
    return kaart
end

return player

